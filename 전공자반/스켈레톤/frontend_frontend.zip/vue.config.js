module.exports = {
  outputDir: '../main/resources/static'
}