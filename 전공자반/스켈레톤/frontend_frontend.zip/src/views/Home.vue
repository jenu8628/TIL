<template>
  <div style="margin-top:100px; margin-bottom:100px;">
    <normal-map></normal-map>
  </div>
</template>

<script>
import NormalMap from "../components/NormalMap.vue";
export default {
  components: { NormalMap }
};
</script>

<style></style>
